const myName = 'Max';

if (myName === 'Max') {
  console.log('Hello!');
}

let isLoggedIn = true;

if (!isLoggedIn) {
  console.log('User is NOT logged in!');
}

const enteredUserName = ''; // 0

if (enteredUserName) {
  console.log('Input is valid!');
}